/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
enum {
     State_Idle=0 , State_Sense , State_Act, State_Display};
enum {
	I_CC=0, I_Ramp_Sqr, I_Ramp_Tri, I_Ramp_Weld1, I_Ramp_Weld2};
enum {
	Ramp_Gen_Inactive=0,Ramp_Gen_Active};
enum {
	Low=0, High};

/*
 * I_CC: Static Constant Current Set Value
 * I_Ramp_Sqr: Square wave for stability test
 * I_Ramp_Tri: Triangular wave
 * I_Ramp_Weld1: Welding Profile#1 in DMA
 */

#define Ramp_Event_Down_Cntr_Max 250 // Each (Ramp_Event_Down_Cntr_Max) x (SysTicks) , DAC Generates a Ramp
#define V_Ramp_Time_Length_us 2000 //microseconds
#define V_Ramp_Time_Resolution_us 50 //microseconds
#define ADC_Min_Ramp_THD 400
#define ADC_Min_Ramp_THD_Hyst 40

#define AV_Gain 3.5
#define R_Hall_Sensor 3.125 // [mv/Amp]
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;

DAC_HandleTypeDef hdac1;
DMA_HandleTypeDef hdma_dac1_ch2;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim3;

UART_HandleTypeDef huart6;

/* USER CODE BEGIN PV */
uint8_t Active_State=0;
uint8_t State_Entrance_Part_F=0;
volatile uint8_t ADC_Scan_Complete_F=0;
uint8_t ADC_Scan_Timer_OVF=0; // Set only for debug purposes, to be reset in final application
volatile uint16_t ADC_Rawdata_Buffer_DMA[160]={0};//={
uint16_t Ea_ADC_Samples[32]={0};
//uint16_t Ea_ADC_Cashed_Samples[10]={0};
uint16_t Io_ADC_Samples[32]={0};
//uint16_t Io_ADC_Cashed_Samples[10]={0};
uint8_t ADC_Channel_Count=sizeof(ADC_Rawdata_Buffer_DMA)/sizeof(ADC_Rawdata_Buffer_DMA[0]);
uint16_t I_Set_ADC_Value=0;
uint16_t Ea_Av=0;
uint16_t Io_Av=0;
uint16_t Io_Ramp_Weld1_Av=0;
uint16_t Io_Ramp_Weld2_Av=0;
uint16_t Ea_Av_mV=0;
uint16_t Ea_Av_mV_THD=1900; //mV
uint16_t Io_Av_A=0;
uint16_t Ea_ADC_Value;
uint16_t Io_ADC_Value;
uint8_t Rweld=0;
uint8_t Num_Ea_ADC_Samples= (uint8_t)((sizeof(Ea_ADC_Samples))/sizeof(Ea_ADC_Samples[0]));
uint8_t Num_Io_ADC_Samples= (uint8_t)((sizeof(Io_ADC_Samples))/sizeof(Io_ADC_Samples[0]));
uint32_t Samples_Array_Members_Sum=0;
//uint16_t I_Ramp_Peak_Value=(200*AV_Gain*R_Hall_Sensor*0xFFF/((uint16_t)(Vref_Step_Down*DAC_Vref)));// 200 is in Amps
uint16_t I_Set_ADC_Offset= 150; // This value can be found by calibration. This amount was measured
//uint16_t I_Weld_ADC_Value=0;
uint32_t Multip_Buffer=0;
uint8_t New_SysTick_F=0;
uint32_t Last_DAC_Value=0;
uint32_t I_Set_Amperes=0;
Ramp_t my_Ramp_Init_t;
HMI_t hHMI;
uint16_t Ramp_Weld1_Arraysize=500;
uint16_t Ramp_Weld2_Arraysize=500;
uint16_t Ramp_Weld1_Array[500]={0};
uint16_t Ramp_Weld2_Array[500]={0};
uint16_t Rampdown_Weld_Array[250]={0};
uint16_t Rampdown_Weld_Arraysize= (uint16_t)((sizeof(Rampdown_Weld_Array))/sizeof(Rampdown_Weld_Array[0]));

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_ADC1_Init(void);
static void MX_DAC1_Init(void);
static void MX_USART6_UART_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM3_Init(void);
/* USER CODE BEGIN PFP */

void PSFB_CTRL_Config(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void Ramp_Generator_Config(Ramp_t *);
void Ramp_Generator_Start(Ramp_t *);
uint16_t MovingAverage_Ea(uint16_t, uint16_t*, uint8_t);
uint16_t MovingAverage_Io(uint16_t, uint16_t*, uint8_t);
void UpdateSamples_Ea(uint16_t ,uint16_t* ,uint8_t);
void UpdateSamples_Io(uint16_t ,uint16_t* ,uint8_t);
void Extract_ADC_Arrays(uint16_t*,uint16_t*,uint16_t *, uint8_t);
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
  MX_DAC1_Init();
  MX_USART6_UART_Init();
  MX_TIM1_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);
  HAL_SYSTICK_Config(28000); // Sys Tick Interrupt every 0.5ms
  PSFB_CTRL_Config();



  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

	  // At each Tick, The values of some Pins/ Variables are polled.
	 	  	 	  while(New_SysTick_F==0)
	 	  	 	  	  	  {;}
	 	  	 	  New_SysTick_F=0; // Getting here means a new SysTick ticked, and the flag has been set in the callback..
	 	  	 	  HAL_GPIO_TogglePin(DO_Inv_Outdrv_Dis_GPIO_Port, DO_Inv_Outdrv_Dis_Pin);

	 	  	 	  	 	    	  switch(Active_State)
	 	  	 	  	 	    	  {
	 	  	 	  	 	    	  case State_Idle:
	 	  	 	  	 	    		  Active_State=State_Sense;
	 	  	 	  	 	    		  State_Entrance_Part_F=0;
	 	  	 	  	 	    		  ADC_Scan_Timer_OVF=1; // Just for debugging, remove later
	 	  	 	  	 	    		  break;

	 	  	 	  	 	    	  case State_Sense:
	 	  	 	  	 	    		  // Here, the Potentiometer is sensed.
	 	  	 	  	 	    		  if(State_Entrance_Part_F==0)
	 	  	 	  	 	    		  {
	 	  	 	  	 	    			 if(ADC_Scan_Timer_OVF==1)
	 	  	 	  	 	    			 {
	 	  	 	  	 	    			State_Entrance_Part_F=1;
	 	  	 	  	 	    			ADC_Scan_Timer_OVF=0; // Reset the Scan Timer Overflow Flag
	 	  	 	  	 	    			//HAL_ADC_Start_IT(&hadc1); // Starts ADC Conversion, by passing the handle to the HAL_ADC_Start_IT()
	 	  	 	  	 	    			 HAL_ADC_Start_DMA(&hadc1,(uint32_t*) &ADC_Rawdata_Buffer_DMA, ADC_Channel_Count);
	 	  	 	  	 	    			 }
	 	  	 	  	 	    		  }
	 	  	 	  	 	    		  else

	 	  	 	  	 	    		  	 {
	 	  	 	  	 	    			 // Do Part
	 	  	 	  	 	    			 if (ADC_Scan_Complete_F)
	 	  	 	  	 	    			 	  	 {

	 	  	 	  	 	    			 	  	 	//HAL_ADC_Stop_DMA(&hadc1);
	 	  	 	  	 	    			 	  	 	ADC_Scan_Complete_F=0;
	 	  	 	  	 	    			 	  	 	I_Set_ADC_Value=ADC_Rawdata_Buffer_DMA[0];
	 	  	 	  	 	    			 	  	 	  	 	  //taking out the offset from measured Potentiometer ADC.
	 	  	 	  	 	    			 	  	 	if(I_Set_ADC_Value>I_Set_ADC_Offset)
	 	  	 	  	 	    			 	  	 	  	{
	 	  	 	  	 	    			 	  	 	  	 I_Set_ADC_Value-=I_Set_ADC_Offset;
	 	  	 	  	 	    			 	  	 	  	 }
	 	  	 	  	 	    			 	  	 	  	 else
	 	  	 	  	 	    			 	  	 	  	 	I_Set_ADC_Value=0;




	 	  	 	  	 	    			 	  	  Active_State=State_Act;
	 	  	 	  	 	    			 	  	  State_Entrance_Part_F=0;
	 	  	 	  	 	    			 	  	 	  	 	    	//DAC_Ramping_En_F=0;
	 	  	 	  	 	    			 	  	 	  	 	    	}


	 	  	 	  	 	    			 	  	 	  	 	    			 			 //Checking if I_Set_ADC_Value is less than ADC_Value_Min_Ramp_THD
	 	  	 	  	 	    			 	  	 	  	 	    			 			 // if(I_Set_ADC_Value < ADC_Min_Ramp_THD)
	 	  	 	  	 	    			 	  	 	  	 	    			 			 //{
	 	  	 	  	 	    			 	  	 	  	 	    			 			 // }
	 	  	 	  	 	    			 	  	 	  	 	    			 			 // if(I_Set_ADC_Value > (ADC_Min_Ramp_THD +ADC_Min_Ramp_THD_Hyst))
	 	  	 	  	 	    			 	  	 	  	 	    			 			 // {
	 	  	 	  	 	    			 	  	 	  	 	    			 			 //  DAC_Ramping_En_F=1;
	 	  	 	  	 	    			 	  	 	  	 	    			 			 // }
	 	  	 	  	 	    			 }
	 	  	 	  	 	    		  break;

	 	  	 	  	 	    	  case State_Act:
	 	  	 	  	 	    		  	  //Embodies the "Ramp" Generation function call.
	 	  	 	  	 	    			  // Do Part of the state
	 	  	 	  	 	    			  // Call the Ramp Generator Function
	 	  	 	  	 	    		 //HAL_GPIO_WritePin(DO_Inv_Outdrv_Dir_GPIO_Port, DO_Inv_Outdrv_Dir_Pin, GPIO_PIN_SET);
	 	  	 	  	 	    		 Ea_Av= MovingAverage_Ea(Ea_ADC_Value,(uint16_t*) &Ea_ADC_Samples,Num_Ea_ADC_Samples);
	 	  	 	  	 	    		 Ea_Av_mV=(uint16_t)(Ea_Av*2*3300/(0xFFF));

	 	  	 	  	 	    		 Io_Av= MovingAverage_Io(Io_ADC_Value,(uint16_t*) &Io_ADC_Samples,Num_Io_ADC_Samples);
	 	  	 	  	 	    		 Io_Av_A=(uint16_t)((Io_Av*((uint16_t)(Vref_Step_Down*DAC_Vref)/0xFFF))/(AV_Gain*R_Hall_Sensor));
	 	  	 	  	 	    		 Io_Ramp_Weld1_Av=(my_Ramp_Init_t.Ivalley)+5;
	 	  	 	  	 	    		 //HAL_GPIO_WritePin(DO_Inv_Outdrv_Dir_GPIO_Port, DO_Inv_Outdrv_Dir_Pin, GPIO_PIN_RESET);
/*
	 	  	 	  	 	    		 if(Ea_Av_mV>2200)
	 	  	 	  	 	    			 Rweld=High;
	 	  	 	  	 	    		 else
	 	  	 	  	 	    			 Rweld=Low;
*/
	 	  	 	  	 	    		 Ramp_Generator_Start(&my_Ramp_Init_t);
	 	  	 	  	 	    		 Last_DAC_Value= HAL_DAC_GetValue(&hdac1, DAC_CHANNEL_2);
	 	  	 	  	 	    		 I_Set_Amperes = I_Set_ADC_Value*(uint16_t)(Vref_Step_Down*DAC_Vref)/0xFFF/AV_Gain/R_Hall_Sensor;
	 	  	 	  	 	    		 HMI_Display(I_Set_Amperes);
	 	  	 	  	 	    		 Active_State=State_Idle;
	 	  	 	  	 	    		 State_Entrance_Part_F=0;

	 	  	 	  	 	    	    break;
/*
	 	  	 	  	 	    	  case State_Display:

	 	  	 	  	 	    		  if(State_Entrance_Part_F==0)
	 	  	 	  	 	    		 	  {
	 	  	 	  	 	    		 	  	State_Entrance_Part_F=1;
	 	  	 	  	 	    		 	  	// Calculating back the Value of Nominal Current in Amperes
	 	  	 	  	 	    		 	  	 I_Set_Amperes = I_Set_ADC_Value*(uint16_t)(Vref_Step_Down*DAC_Vref)/0xFFF/AV_Gain/R_Hall_Sensor;


	 	  	 	  	 	    		 	  }
	 	  	 	  	 	    		  if (State_Entrance_Part_F==1)

	 	  	 	  	 	    		  {
	 	  	 	  	 	    			  //handle_hmi((uint16_t)(I_Set_Amperes));
	 	  	 	  	 	    			  State_Entrance_Part_F=0;
	 	  	 	  	 	    			  Active_State=State_Idle;
	 	                              }
	 	  	 	  	 	    		  break;
*/


	 	  	 	  	 	    	  }
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV1;
  RCC_OscInitStruct.PLL.PLLN = 16;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV2;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.ScanConvMode = ADC_SCAN_ENABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SEQ_CONV;
  hadc1.Init.LowPowerAutoWait = DISABLE;
  hadc1.Init.LowPowerAutoPowerOff = DISABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.NbrOfConversion = 5;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.DMAContinuousRequests = ENABLE;
  hadc1.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc1.Init.SamplingTimeCommon1 = ADC_SAMPLETIME_79CYCLES_5;
  hadc1.Init.SamplingTimeCommon2 = ADC_SAMPLETIME_79CYCLES_5;
  hadc1.Init.OversamplingMode = DISABLE;
  hadc1.Init.TriggerFrequencyMode = ADC_TRIGGER_FREQ_HIGH;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_9;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLINGTIME_COMMON_1;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_8;
  sConfig.Rank = ADC_REGULAR_RANK_2;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_3;
  sConfig.Rank = ADC_REGULAR_RANK_3;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_2;
  sConfig.Rank = ADC_REGULAR_RANK_4;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = ADC_REGULAR_RANK_5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */
  // CH9 = AI_I_Set
  // CH1 = AI_Ea, HW modification on AI_Temp_QD to measure Ea
  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief DAC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_DAC1_Init(void)
{

  /* USER CODE BEGIN DAC1_Init 0 */

  /* USER CODE END DAC1_Init 0 */

  DAC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN DAC1_Init 1 */

  /* USER CODE END DAC1_Init 1 */

  /** DAC Initialization
  */
  hdac1.Instance = DAC1;
  if (HAL_DAC_Init(&hdac1) != HAL_OK)
  {
    Error_Handler();
  }

  /** DAC channel OUT2 config
  */
  sConfig.DAC_SampleAndHold = DAC_SAMPLEANDHOLD_ENABLE;
  sConfig.DAC_Trigger = DAC_TRIGGER_T3_TRGO;
  sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
  sConfig.DAC_ConnectOnChipPeripheral = DAC_CHIPCONNECT_DISABLE;
  sConfig.DAC_UserTrimming = DAC_TRIMMING_FACTORY;
  sConfig.DAC_SampleAndHoldConfig.DAC_SampleTime = 0;
  sConfig.DAC_SampleAndHoldConfig.DAC_HoldTime = 0;
  sConfig.DAC_SampleAndHoldConfig.DAC_RefreshTime = 0;
  if (HAL_DAC_ConfigChannel(&hdac1, &sConfig, DAC_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN DAC1_Init 2 */

  /* USER CODE END DAC1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.BreakFilter = 0;
  sBreakDeadTimeConfig.BreakAFMode = TIM_BREAK_AFMODE_INPUT;
  sBreakDeadTimeConfig.Break2State = TIM_BREAK2_DISABLE;
  sBreakDeadTimeConfig.Break2Polarity = TIM_BREAK2POLARITY_HIGH;
  sBreakDeadTimeConfig.Break2Filter = 0;
  sBreakDeadTimeConfig.Break2AFMode = TIM_BREAK_AFMODE_INPUT;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 0;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 3200;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief USART6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART6_UART_Init(void)
{

  /* USER CODE BEGIN USART6_Init 0 */

  /* USER CODE END USART6_Init 0 */

  /* USER CODE BEGIN USART6_Init 1 */

  /* USER CODE END USART6_Init 1 */
  huart6.Instance = USART6;
  huart6.Init.BaudRate = 115200;
  huart6.Init.WordLength = UART_WORDLENGTH_8B;
  huart6.Init.StopBits = UART_STOPBITS_1;
  huart6.Init.Parity = UART_PARITY_NONE;
  huart6.Init.Mode = UART_MODE_TX_RX;
  huart6.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart6.Init.OverSampling = UART_OVERSAMPLING_16;
  huart6.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart6.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart6.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_RS485Ex_Init(&huart6, UART_DE_POLARITY_HIGH, 0, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART6_Init 2 */

  /* USER CODE END USART6_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);
  /* DMA1_Channel2_3_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel2_3_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel2_3_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, DO_7SEG_DISP3_EN_Pin|DO_7SEG_BCD_D_Pin|DO_7SEG_BCD_C_Pin|DO_7SEG_BCD_B_Pin
                          |DO_7SEG_BCD_A_Pin|nComm_Rx_EN_Pin|DO_7SEG_DISP2_EN_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, DO_Abrupt_I_Off_Pin|nDO_PSFB_CTRL_On_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(DO_G_DRV_EN_GPIO_Port, DO_G_DRV_EN_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, DO_Inv_Predrv_En_Pin|DO_Inv_Outdrv_Dir_Pin|DO_Inv_Outdrv_Dis_Pin|DO_7SEG_DISP1_EN_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : DO_7SEG_DISP3_EN_Pin DO_7SEG_BCD_D_Pin DO_7SEG_BCD_C_Pin DO_7SEG_BCD_B_Pin
                           DO_7SEG_BCD_A_Pin nComm_Rx_EN_Pin DO_7SEG_DISP2_EN_Pin */
  GPIO_InitStruct.Pin = DO_7SEG_DISP3_EN_Pin|DO_7SEG_BCD_D_Pin|DO_7SEG_BCD_C_Pin|DO_7SEG_BCD_B_Pin
                          |DO_7SEG_BCD_A_Pin|nComm_Rx_EN_Pin|DO_7SEG_DISP2_EN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : DO_Abrupt_I_Off_Pin */
  GPIO_InitStruct.Pin = DO_Abrupt_I_Off_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(DO_Abrupt_I_Off_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : nDO_PSFB_CTRL_On_Pin */
  GPIO_InitStruct.Pin = nDO_PSFB_CTRL_On_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(nDO_PSFB_CTRL_On_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : DO_G_DRV_EN_Pin */
  GPIO_InitStruct.Pin = DO_G_DRV_EN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(DO_G_DRV_EN_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : DI_G_DRV_RDY_Pin nDI_G_DRV_FaultD_Pin nDI_G_DRV_FaultC_Pin nDI_G_DRV_FaultB_Pin
                           nDI_G_DRV_FaultA_Pin */
  GPIO_InitStruct.Pin = DI_G_DRV_RDY_Pin|nDI_G_DRV_FaultD_Pin|nDI_G_DRV_FaultC_Pin|nDI_G_DRV_FaultB_Pin
                          |nDI_G_DRV_FaultA_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pin : DI_Outdrv_Fault_Pin */
  GPIO_InitStruct.Pin = DI_Outdrv_Fault_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(DI_Outdrv_Fault_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : DO_Inv_Predrv_En_Pin DO_Inv_Outdrv_Dis_Pin DO_7SEG_DISP1_EN_Pin */
  GPIO_InitStruct.Pin = DO_Inv_Predrv_En_Pin|DO_Inv_Outdrv_Dis_Pin|DO_7SEG_DISP1_EN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : DO_Inv_Outdrv_Dir_Pin */
  GPIO_InitStruct.Pin = DO_Inv_Outdrv_Dir_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(DO_Inv_Outdrv_Dir_GPIO_Port, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void HAL_SYSTICK_Callback(void)
{
	 New_SysTick_F=1;
	 //HAL_GPIO_WritePin(SW_Debug_GPIO_Port, SW_Debug_Pin, GPIO_PIN_SET);
	 //HAL_GPIO_TogglePin(SW_Debug_GPIO_Port, SW_Debug_Pin);
     //HAL_GPIO_WritePin(SW_Debug_GPIO_Port, SW_Debug_Pin, GPIO_PIN_RESET);
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *pTimer)

{
// Checking which Timer Caused the Event
	if(pTimer==&(my_Ramp_Init_t.ramp_timer))
	{
		my_Ramp_Init_t.ramp_timer_Tout=1;// Setting the flag
/*
	 HAL_DAC_SetValue(&hdac1, DAC_CHANNEL_2, DAC_ALIGN_12B_R, DAC_Buffer_Value);
	 //HAL_GPIO_TogglePin(SW_Debug_GPIO_Port, SW_Debug_Pin);
	 if (DAC_Buffer_Value==I_Ramp_Peak_Value)
		 DAC_Buffer_Value=I_Set_ADC_Value;
	 else
		 DAC_Buffer_Value=I_Ramp_Peak_Value;
*/
	}
 }

//void HAL_DACEx_ConvCpltCallbackCh2(hdac){

//}

void Extract_ADC_Arrays(uint16_t* ADC_Rawdata_Buffer_DMA,uint16_t *Ea_ADC_Samples,uint16_t *Io_ADC_Samples, uint8_t Samples_Array_Size)
{

	//Cashing the existing Ea_ADC_Samples array
	for (uint8_t i=0;i<Samples_Array_Size;i++)
	{
		Ea_ADC_Samples[i]=ADC_Rawdata_Buffer_DMA[5*i+4];// 5 is the total number of ADC channels scanned
		Io_ADC_Samples[i]=ADC_Rawdata_Buffer_DMA[5*i+1];

	}

}

/*
void UpdateSamples_Io(uint16_t New_Io_Sample,uint16_t *Samples_Array, uint8_t Samples_Array_Size)
{
	//Cashing the existing Ea_ADC_Samples array
	for (uint8_t i=0;i<Samples_Array_Size;i++)
	{
		Samples_Array[i]=Io_ADC_Samples[i];
	}
	//Moving the elements one place to the right.
	for (uint8_t i=0;i<Samples_Array_Size;i++)
		{
		Samples_Array[i+1]=Io_ADC_Cashed_Samples[i];
		}


	//Allowing the new ADC sample to occupy location number 0
	Samples_Array[0]=New_Io_Sample;
}
*/

uint16_t MovingAverage_Ea(uint16_t New_Ea_Sample,uint16_t *Samples_Array, uint8_t Samples_Array_Size)
{


	Samples_Array_Members_Sum=0;
	for (uint8_t i=0;i<Samples_Array_Size;i++)
	{
	Samples_Array_Members_Sum+= Samples_Array[i];
	}
	return (uint16_t)(Samples_Array_Members_Sum/(Samples_Array_Size));

	;
}



uint16_t MovingAverage_Io(uint16_t New_Io_Sample,uint16_t *Samples_Array,uint8_t Samples_Array_Size)
{


Samples_Array_Members_Sum=0;
for (uint8_t i=0;i<Samples_Array_Size;i++)
{
Samples_Array_Members_Sum+= Samples_Array[i];
}
return (uint16_t)(Samples_Array_Members_Sum/Samples_Array_Size);

}


void Ramp_Generator_Config(Ramp_t *hRamp_t){
// Configure the timer for desired periodic event

	switch (hRamp_t->Ramptype)
	{


	case I_Ramp_Sqr: // Square Waveform, for Stability of step response testing.


	  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
	  TIM_MasterConfigTypeDef sMasterConfig = {0};
	  TIM_OC_InitTypeDef sConfigOC = {0};

	  //Configuring and Initializing the Ramp Timer.

	  hRamp_t->ramp_timer.Instance = TIM3;
	  hRamp_t->ramp_timer.Init.Prescaler = 128;
	  hRamp_t->ramp_timer.Init.CounterMode = TIM_COUNTERMODE_UP;
	  hRamp_t->ramp_timer.Init.Period = 16000;
	  hRamp_t->ramp_timer.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	  hRamp_t->ramp_timer.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
	  if(HAL_TIM_Base_Init(&(hRamp_t->ramp_timer))!= HAL_OK)
	  {
		  Error_Handler();

	  }

	  HAL_TIM_Base_Start_IT(&(hRamp_t->ramp_timer));
	  HAL_DAC_Start(&hdac1, DAC_CHANNEL_2);


	  //Setting the DAC, no DMA
	 //Copying the CubeMx initialization of DAC without DMA/Timer trigger.
	{
		  /* USER CODE BEGIN DAC1_Init 0 */

		  /* USER CODE END DAC1_Init 0 */

		  DAC_ChannelConfTypeDef sConfig = {0};

		  /* USER CODE BEGIN DAC1_Init 1 */

		  /* USER CODE END DAC1_Init 1 */

		  /** DAC Initialization
		  */
		  hdac1.Instance = DAC1;
		  if (HAL_DAC_Init(&hdac1) != HAL_OK)
		  {
		    Error_Handler();
		  }

		  /** DAC channel OUT2 config
		  */
		  sConfig.DAC_SampleAndHold = DAC_SAMPLEANDHOLD_DISABLE;
		  sConfig.DAC_Trigger = DAC_TRIGGER_NONE;
		  sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
		  sConfig.DAC_ConnectOnChipPeripheral = DAC_CHIPCONNECT_DISABLE;
		  sConfig.DAC_UserTrimming = DAC_TRIMMING_FACTORY;
		  if (HAL_DAC_ConfigChannel(&hdac1, &sConfig, DAC_CHANNEL_2) != HAL_OK)
		  {
		    Error_Handler();
		  }
		  /* USER CODE BEGIN DAC1_Init 2 */

		  /* USER CODE END DAC1_Init 2 */

		}



	  break;

	case I_CC: // Constant Current Mode



		//Setting the DAC, no DMA

		//Copying the CubeMx initialization of DAC without DMA/Timer trigger.
	{
		  /* USER CODE BEGIN DAC1_Init 0 */

		  /* USER CODE END DAC1_Init 0 */

		  DAC_ChannelConfTypeDef sConfig = {0};

		  /* USER CODE BEGIN DAC1_Init 1 */

		  /* USER CODE END DAC1_Init 1 */

		  /** DAC Initialization
		  */
		  hdac1.Instance = DAC1;
		  if (HAL_DAC_Init(&hdac1) != HAL_OK)
		  {
		    Error_Handler();
		  }

		  /** DAC channel OUT2 config
		  */
		  sConfig.DAC_SampleAndHold = DAC_SAMPLEANDHOLD_DISABLE;
		  sConfig.DAC_Trigger = DAC_TRIGGER_NONE;
		  sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
		  sConfig.DAC_ConnectOnChipPeripheral = DAC_CHIPCONNECT_DISABLE;
		  sConfig.DAC_UserTrimming = DAC_TRIMMING_FACTORY;
		  if (HAL_DAC_ConfigChannel(&hdac1, &sConfig, DAC_CHANNEL_2) != HAL_OK)
		  {
		    Error_Handler();
		  }
		  /* USER CODE BEGIN DAC1_Init 2 */

		  /* USER CODE END DAC1_Init 2 */

		}



		HAL_DAC_Start(&hdac1, DAC_CHANNEL_2);
		break;

	case I_Ramp_Weld2:
		//Note that Ramp_Timer_Tout denotes the flag set at end of each DMA CH2 Transfer to DAC
		//Ramp_Timer: used here as sampling timer,whose Tout Event triggers DAC DMA.
		//Copying the TIM3 Settings

	{
		  /* USER CODE BEGIN TIM3_Init 0 */

		  /* USER CODE END TIM3_Init 0 */

	//	  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
	//	  TIM_MasterConfigTypeDef sMasterConfig = {0};

		  /* USER CODE BEGIN TIM3_Init 1 */

		  /* USER CODE END TIM3_Init 1 */
		  htim3.Instance = TIM3;
		  htim3.Init.Prescaler = 0;
		  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
		  htim3.Init.Period = 1600;
		  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
		  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
		  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
		  {
		    Error_Handler();
		  }
		  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
		  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
		  {
		    Error_Handler();
		  }
		  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
		  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
		  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
		  {
		    Error_Handler();
		  }
		  /* USER CODE BEGIN TIM3_Init 2 */

		  /* USER CODE END TIM3_Init 2 */

	}




	//The DAC Settings with DMA used for this waveform


	{
		  /* USER CODE BEGIN DAC1_Init 0 */

		  /* USER CODE END DAC1_Init 0 */

		  DAC_ChannelConfTypeDef sConfig = {0};

		  /* USER CODE BEGIN DAC1_Init 1 */

		  /* USER CODE END DAC1_Init 1 */

		  /** DAC Initialization
		  */
		  hdac1.Instance = DAC1;
		  if (HAL_DAC_Init(&hdac1) != HAL_OK)
		  {
		    Error_Handler();
		  }

		  /** DAC channel OUT2 config
		  */
		  sConfig.DAC_SampleAndHold = DAC_SAMPLEANDHOLD_DISABLE;
		  sConfig.DAC_Trigger = DAC_TRIGGER_T3_TRGO;
		  sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
		  sConfig.DAC_ConnectOnChipPeripheral = DAC_CHIPCONNECT_DISABLE;
		  sConfig.DAC_UserTrimming = DAC_TRIMMING_FACTORY;
		  if (HAL_DAC_ConfigChannel(&hdac1, &sConfig, DAC_CHANNEL_2) != HAL_OK)
		  {
		    Error_Handler();
		  }
		  /* USER CODE BEGIN DAC1_Init 2 */

		  /* USER CODE END DAC1_Init 2 */

		}





	{
	// Creating the Array
	uint16_t nStep1= (uint16_t)( hRamp_t->T_Step1/hRamp_t->T_DAC_Sample); //# samples of I_Step1 duration
	uint16_t nRise= (uint16_t)( hRamp_t->T_Rise/hRamp_t->T_DAC_Sample); // # samples while Current Ramps up
	uint16_t nPeak = (uint16_t)( hRamp_t->T_Peak/hRamp_t->T_DAC_Sample);
	uint16_t nFall= (uint16_t)( hRamp_t->T_Fall/hRamp_t->T_DAC_Sample);// # samples while current ramps down from peak to valley


	uint16_t I_Valley_DAC_Value=(uint16_t)((hRamp_t->Ivalley*R_Hall_Sensor*AV_Gain+Av_Out_Offset)*0xFFF/(uint16_t)(Vref_Step_Down*DAC_Vref));
	uint16_t I_Peak_DAC_Value=(uint16_t)((hRamp_t->Ipeak*R_Hall_Sensor*AV_Gain+Av_Out_Offset)*0xFFF/(uint16_t)(Vref_Step_Down*DAC_Vref));
	uint16_t I_Step1_DAC_Value=(uint16_t)((hRamp_t->I_Step1*R_Hall_Sensor*AV_Gain+Av_Out_Offset)*0xFFF/(uint16_t)(Vref_Step_Down*DAC_Vref));

	uint16_t N_Step1=nStep1; // Number of samples at end of Step1 sub-period
	uint16_t N_Rise= N_Step1 + nRise; // Accumulative samples from Ramp start till I_Peak is reached.
	uint16_t N_Peak=N_Rise+nPeak;		// Accumulative samples from Ramp start till I_Peak finishes
	uint16_t N_Fall=N_Peak +nFall; // Accumulative samples from Ramp start till current Ramps down from Peak to valley.


	//uint16_t Ramp_Weld1_Array[N_Fall]; //Creating the array
		if (N_Fall<=Ramp_Weld2_Arraysize)
 {
	 for (uint16_t i=0; i<N_Step1; i++){
		 Ramp_Weld2_Array[i]=I_Step1_DAC_Value;
	 }
	 for (uint16_t i=N_Step1; i<N_Rise; i++)
	 {
		 Ramp_Weld2_Array[i]=I_Step1_DAC_Value+(uint16_t)((I_Peak_DAC_Value-I_Step1_DAC_Value)*(i-N_Step1)/(nRise));

	 }
	 for (uint16_t i=N_Rise; i<N_Peak; i++)
		 {
			 Ramp_Weld2_Array[i]=I_Peak_DAC_Value;

		 }

	 for (uint16_t i=N_Peak; i<N_Fall; i++)
	 {
		 Ramp_Weld2_Array[i]=I_Peak_DAC_Value-(uint16_t)((I_Peak_DAC_Value-I_Valley_DAC_Value)*(i-N_Peak)/(nFall));
	 }

	 for (uint16_t i=N_Fall; i<Ramp_Weld1_Arraysize; i++)
	 {
		 Ramp_Weld2_Array[i]=I_Valley_DAC_Value;
	 }
	//Ramp_Weld2_Arraysize=N_Fall; // Removing this line made waveform very arbitrary
	//Io_Ramp_Weld1_Av=(uint16_t)((nStep1+nRise)*(hRamp_t->I_Step1)+0.5*nRise*((hRamp_t->Ipeak)-(hRamp_t->I_Step1))+0.5*nFall*((hRamp_t->Ipeak)-(hRamp_t->Ivalley)))/(N_Fall);
	Io_Ramp_Weld2_Av=(hRamp_t->Ivalley)+5;// Value in Ampere,


	uint16_t I_Vally_Rampdown_DAC_Value=(uint16_t)(((hRamp_t->Ivalley-hRamp_t->I_Rampdown)*R_Hall_Sensor*AV_Gain+Av_Out_Offset)*0xFFF/(uint16_t)(Vref_Step_Down*DAC_Vref));

	for (uint16_t i=0; i<Rampdown_Weld_Arraysize; i++)
	{
		Rampdown_Weld_Array[i]=(uint16_t)(I_Valley_DAC_Value-(I_Valley_DAC_Value-I_Vally_Rampdown_DAC_Value)*i/(Rampdown_Weld_Arraysize));
	}


 }

	}




	break;

	case I_Ramp_Weld1:


	//Note that Ramp_Timer_Tout denotes the flag set at end of each DMA CH2 Transfer to DAC
	//Ramp_Timer: used here as sampling timer,whose Tout Event triggers DAC DMA.
	//Copying the TIM3 Settings

{
	  /* USER CODE BEGIN TIM3_Init 0 */

	  /* USER CODE END TIM3_Init 0 */

	  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
	  TIM_MasterConfigTypeDef sMasterConfig = {0};

	  /* USER CODE BEGIN TIM3_Init 1 */

	  /* USER CODE END TIM3_Init 1 */
	  htim3.Instance = TIM3;
	  htim3.Init.Prescaler = 0;
	  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
	  htim3.Init.Period = 1600;
	  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
	  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
	  {
	    Error_Handler();
	  }
	  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
	  {
	    Error_Handler();
	  }
	  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
	  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
	  {
	    Error_Handler();
	  }
	  /* USER CODE BEGIN TIM3_Init 2 */

	  /* USER CODE END TIM3_Init 2 */

}




//The DAC Settings with DMA used for this waveform


{
	  /* USER CODE BEGIN DAC1_Init 0 */

	  /* USER CODE END DAC1_Init 0 */

	  DAC_ChannelConfTypeDef sConfig = {0};

	  /* USER CODE BEGIN DAC1_Init 1 */

	  /* USER CODE END DAC1_Init 1 */

	  /** DAC Initialization
	  */
	  hdac1.Instance = DAC1;
	  if (HAL_DAC_Init(&hdac1) != HAL_OK)
	  {
	    Error_Handler();
	  }

	  /** DAC channel OUT2 config
	  */
	  sConfig.DAC_SampleAndHold = DAC_SAMPLEANDHOLD_DISABLE;
	  sConfig.DAC_Trigger = DAC_TRIGGER_T3_TRGO;
	  sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
	  sConfig.DAC_ConnectOnChipPeripheral = DAC_CHIPCONNECT_DISABLE;
	  sConfig.DAC_UserTrimming = DAC_TRIMMING_FACTORY;
	  if (HAL_DAC_ConfigChannel(&hdac1, &sConfig, DAC_CHANNEL_2) != HAL_OK)
	  {
	    Error_Handler();
	  }
	  /* USER CODE BEGIN DAC1_Init 2 */

	  /* USER CODE END DAC1_Init 2 */

	}




{

// Creating the Array
uint16_t nStep1= (uint16_t)( hRamp_t->T_Step1/hRamp_t->T_DAC_Sample); //# samples of I_Step1 duration
uint16_t nRise= (uint16_t)( hRamp_t->T_Rise/hRamp_t->T_DAC_Sample); // # samples while Current Ramps up
uint16_t nFall= (uint16_t)( hRamp_t->T_Fall/hRamp_t->T_DAC_Sample);// # samples while current ramps down from peak to valley


uint16_t I_Valley_DAC_Value=(uint16_t)((hRamp_t->Ivalley*R_Hall_Sensor*AV_Gain+Av_Out_Offset)*0xFFF/(uint16_t)(Vref_Step_Down*DAC_Vref));
uint16_t I_Peak_DAC_Value=(uint16_t)((hRamp_t->Ipeak*R_Hall_Sensor*AV_Gain+Av_Out_Offset)*0xFFF/(uint16_t)(Vref_Step_Down*DAC_Vref));
uint16_t I_Step1_DAC_Value=(uint16_t)((hRamp_t->I_Step1*R_Hall_Sensor*AV_Gain+Av_Out_Offset)*0xFFF/(uint16_t)(Vref_Step_Down*DAC_Vref));


uint16_t N_Step1=nStep1; // Number of samples at end of Step1 sub-period
uint16_t N_Rise= N_Step1 + nRise; // Accumulative samples from Ramp start till I_Peak is reached.
uint16_t N_Fall=N_Rise +nFall; // Accumulative samples from Ramp start till current Ramps down from Peak to valley.


//uint16_t Ramp_Weld1_Array[N_Fall]; //Creating the array
	if (N_Fall<=Ramp_Weld1_Arraysize)
{
 for (uint16_t i=0; i<N_Step1; i++){
	 Ramp_Weld1_Array[i]=I_Step1_DAC_Value;
 }
 for (uint16_t i=N_Step1; i<N_Rise; i++)
 {
	 Ramp_Weld1_Array[i]=I_Step1_DAC_Value+(uint16_t)((I_Peak_DAC_Value-I_Step1_DAC_Value)*(i-N_Step1)/(nRise));

 }
 for (uint16_t i=N_Rise; i<N_Fall; i++)
 {
	 Ramp_Weld1_Array[i]=I_Peak_DAC_Value-(uint16_t)((I_Peak_DAC_Value-I_Valley_DAC_Value)*(i-N_Rise)/(nFall));
 }

 for (uint16_t i=N_Fall; i<Ramp_Weld1_Arraysize; i++)
 {
	 Ramp_Weld1_Array[i]=I_Valley_DAC_Value;
 }
//Ramp_Weld1_Arraysize=N_Fall; // Removing this line made waveform very arbitrary
//Io_Ramp_Weld1_Av=(uint16_t)((nStep1+nRise)*(hRamp_t->I_Step1)+0.5*nRise*((hRamp_t->Ipeak)-(hRamp_t->I_Step1))+0.5*nFall*((hRamp_t->Ipeak)-(hRamp_t->Ivalley)))/(N_Fall);
Io_Ramp_Weld1_Av=(hRamp_t->Ivalley)+5;// Value in Ampere,


uint16_t I_Vally_Rampdown_DAC_Value=(uint16_t)(((hRamp_t->Ivalley-hRamp_t->I_Rampdown)*R_Hall_Sensor*AV_Gain+Av_Out_Offset)*0xFFF/(uint16_t)(Vref_Step_Down*DAC_Vref));

for (uint16_t i=0; i<Rampdown_Weld_Arraysize; i++)
{
	Rampdown_Weld_Array[i]=I_Vally_Rampdown_DAC_Value;
}


}

}




break;






	}
}

void Ramp_Generator_Start(Ramp_t *hRamp_t)
{
	//HAL_GPIO_TogglePin(DO_Inv_Outdrv_Dis_GPIO_Port, DO_Inv_Outdrv_Dis_Pin);
	static uint16_t I_Buffer_DAC_Value;
	uint16_t I_Valley_DAC_Value=(uint16_t)((hRamp_t->Ivalley*R_Hall_Sensor*AV_Gain+Av_Out_Offset)*0xFFF/(uint16_t)(Vref_Step_Down*DAC_Vref));
	uint16_t I_Peak_DAC_Value=(uint16_t)((hRamp_t->Ipeak*R_Hall_Sensor*AV_Gain+Av_Out_Offset)*0xFFF/(uint16_t)(Vref_Step_Down*DAC_Vref));
	//define state machine static variable to hold the active state
	switch(hRamp_t->Ramptype)
	{
	case I_CC:
		I_Buffer_DAC_Value=I_Set_ADC_Value;
		HAL_DAC_SetValue(&hdac1, DAC_CHANNEL_2, DAC_ALIGN_12B_R, I_Buffer_DAC_Value);
		break;

	case I_Ramp_Sqr:
			switch(hRamp_t->Ramp_Gen_State)
			{
			case Ramp_Gen_Inactive:
				if(I_Set_ADC_Value <= I_Valley_DAC_Value)
				{
				I_Buffer_DAC_Value=I_Set_ADC_Value;// DAC shall Generate a voltage proportional to Potentiometer setting
				}
				else if (I_Set_ADC_Value>(I_Valley_DAC_Value+10))
				{
				I_Buffer_DAC_Value=I_Valley_DAC_Value;
				hRamp_t->Ramp_Gen_State= Ramp_Gen_Active;
				}

				HAL_DAC_SetValue(&hdac1, DAC_CHANNEL_2, DAC_ALIGN_12B_R, I_Buffer_DAC_Value);
				break;

			case Ramp_Gen_Active:
				if(hRamp_t->ramp_timer_Tout==1)
				{
					//Each ramp timer Tout Event, toggles the DAC level value.
					hRamp_t->ramp_timer_Tout=0; //Resetting the Flag
					if(I_Buffer_DAC_Value==I_Peak_DAC_Value)
					{
						I_Buffer_DAC_Value=I_Valley_DAC_Value;
						HAL_DAC_SetValue(&hdac1, DAC_CHANNEL_2, DAC_ALIGN_12B_R, I_Buffer_DAC_Value);
					}
					else
					{
						I_Buffer_DAC_Value=I_Peak_DAC_Value;
						HAL_DAC_SetValue(&hdac1, DAC_CHANNEL_2, DAC_ALIGN_12B_R, I_Buffer_DAC_Value);
					}

					//Always at exit a check is done if Potentiometer is set again to less than Valley Current
					if(I_Set_ADC_Value < (I_Valley_DAC_Value-10))
							{
						hRamp_t->Ramp_Gen_State= Ramp_Gen_Inactive;
							}
				}
				break;
			}
		break;

	case I_Ramp_Weld1:

		//HAL_GPIO_WritePin(DO_Inv_Outdrv_Dis_GPIO_Port, DO_Inv_Outdrv_Dis_Pin, GPIO_PIN_RESET);
		//HAL_GPIO_WritePin(DO_Inv_Outdrv_Dir_GPIO_Port, DO_Inv_Outdrv_Dir_Pin, GPIO_PIN_SET);
		//HAL_GPIO_TogglePin(DO_Inv_Outdrv_Dir_GPIO_Port, DO_Inv_Outdrv_Dir_Pin);
		switch(hRamp_t->Ramp_Gen_State)
			{

						case Ramp_Gen_Inactive:

							if(I_Set_ADC_Value <= I_Valley_DAC_Value)
							{
							I_Buffer_DAC_Value=I_Set_ADC_Value;// DAC shall Generate a voltage proportional to Potentiometer setting
							HAL_DAC_SetValue(&hdac1, DAC_CHANNEL_2, DAC_ALIGN_12B_R,I_Buffer_DAC_Value);
							}

							else if (I_Set_ADC_Value>(I_Valley_DAC_Value+10))
							{
									 I_Buffer_DAC_Value=I_Valley_DAC_Value;


									 //HAL_GPIO_WritePin(DO_Inv_Outdrv_Dis_GPIO_Port, DO_Inv_Outdrv_Dis_Pin, GPIO_PIN_SET);




									// This part detects the increase of ARC's resistance : Increase in Ea, and Measured Current reduction below set value.

									if(Rweld==High)
									{
									HAL_GPIO_TogglePin(DO_Inv_Outdrv_Dis_GPIO_Port, DO_Inv_Outdrv_Dis_Pin);
									hRamp_t->Ramp_Gen_State= Ramp_Gen_Inactive;
//									HAL_DAC_Stop_DMA(&hdac1, DAC_CHANNEL_2);
									HAL_DAC_SetValue(&hdac1, DAC_CHANNEL_2, DAC_ALIGN_12B_R,I_Buffer_DAC_Value);
									}

									else

									{
										hRamp_t->Ramp_Gen_State= Ramp_Gen_Active;
										HAL_TIM_Base_Start(&(hRamp_t->ramp_timer));
										HAL_DAC_Start_DMA(&hdac1, DAC_CHANNEL_2, Ramp_Weld1_Array, Ramp_Weld1_Arraysize, DAC_ALIGN_12B_R);
										//HAL_GPIO_WritePin(DO_Inv_Outdrv_Dir_GPIO_Port, DO_Inv_Outdrv_Dir_Pin, GPIO_PIN_SET);
									}

							}

							//HAL_DAC_SetValue(&hdac1, DAC_CHANNEL_2, DAC_ALIGN_12B_R, I_Buffer_DAC_Value);
							break;

						case Ramp_Gen_Active:
							if(my_Ramp_Init_t.ramp_timer_Tout==1)
							{

								my_Ramp_Init_t.ramp_timer_Tout=0;
								my_Ramp_Init_t.Ramp_Gen_State=Ramp_Gen_Inactive;
								//HAL_GPIO_WritePin(DO_Inv_Outdrv_Dir_GPIO_Port, DO_Inv_Outdrv_Dir_Pin, GPIO_PIN_RESET);
								//HAL_DAC_SetValue(&hdac1, DAC_CHANNEL_2, DAC_ALIGN_12B_R,I_Valley_DAC_Value);
								//HAL_DAC_Stop_DMA(&hdac1, DAC_CHANNEL_2);

								//HAL_DAC_SetValue(&hdac1, DAC_CHANNEL_2, DAC_ALIGN_12B_R,I_Valley_DAC_Value);

							}
							//else

							//HAL_DAC_Start_DMA(&hdac1, DAC_CHANNEL_2, Ramp_Weld1_Array, Ramp_Weld1_Arraysize, DAC_ALIGN_12B_R);


							//Always at exit a check is done if Potentiometer is set again to less than Valley Current
								if(I_Set_ADC_Value < (I_Valley_DAC_Value-10))
									{
									 hRamp_t->Ramp_Gen_State= Ramp_Gen_Inactive;
									}
							break;
			}
		break;


				case I_Ramp_Weld2:

								//HAL_GPIO_WritePin(DO_Inv_Outdrv_Dis_GPIO_Port, DO_Inv_Outdrv_Dis_Pin, GPIO_PIN_RESET);
								//HAL_GPIO_WritePin(DO_Inv_Outdrv_Dir_GPIO_Port, DO_Inv_Outdrv_Dir_Pin, GPIO_PIN_SET);
								//HAL_GPIO_TogglePin(DO_Inv_Outdrv_Dir_GPIO_Port, DO_Inv_Outdrv_Dir_Pin);
								switch(hRamp_t->Ramp_Gen_State)
									{

												case Ramp_Gen_Inactive:

													if(I_Set_ADC_Value <= I_Valley_DAC_Value)
													{
													I_Buffer_DAC_Value=I_Set_ADC_Value;// DAC shall Generate a voltage proportional to Potentiometer setting

													HAL_DAC_SetValue(&hdac1, DAC_CHANNEL_2, DAC_ALIGN_12B_R,I_Buffer_DAC_Value);
													}

													else if (I_Set_ADC_Value>(I_Valley_DAC_Value+10))
													{
															 I_Buffer_DAC_Value=I_Valley_DAC_Value;


															 //HAL_GPIO_WritePin(DO_Inv_Outdrv_Dis_GPIO_Port, DO_Inv_Outdrv_Dis_Pin, GPIO_PIN_SET);

															// This part detects the increase of ARC's resistance : Increase in Ea, and Measured Current reduction below set value.

															if(Rweld==High)
															{
															//HAL_GPIO_TogglePin(DO_Inv_Outdrv_Dis_GPIO_Port, DO_Inv_Outdrv_Dis_Pin);
															hRamp_t->Ramp_Gen_State= Ramp_Gen_Active;
															HAL_TIM_Base_Start(&(hRamp_t->ramp_timer));
															HAL_DAC_Start_DMA(&hdac1, DAC_CHANNEL_2, Rampdown_Weld_Array, Rampdown_Weld_Arraysize, DAC_ALIGN_12B_R);

															//HAL_DAC_Stop_DMA(&hdac1, DAC_CHANNEL_2);
															//HAL_DAC_SetValue(&hdac1, DAC_CHANNEL_2, DAC_ALIGN_12B_R,I_Buffer_DAC_Value);
															Rweld=Low;// Flag is reset with the start of a new Ramp check
															}

															else

															{
																hRamp_t->Ramp_Gen_State= Ramp_Gen_Active;
																HAL_TIM_Base_Start(&(hRamp_t->ramp_timer));
																HAL_DAC_Start_DMA(&hdac1, DAC_CHANNEL_2, Ramp_Weld2_Array, Ramp_Weld2_Arraysize, DAC_ALIGN_12B_R);
																//HAL_GPIO_WritePin(DO_Inv_Outdrv_Dis_GPIO_Port, DO_Inv_Outdrv_Dis_Pin, GPIO_PIN_SET);
															}

													}

													//HAL_DAC_SetValue(&hdac1, DAC_CHANNEL_2, DAC_ALIGN_12B_R, I_Buffer_DAC_Value);
													break;

												case Ramp_Gen_Active:
													if(my_Ramp_Init_t.ramp_timer_Tout==1)
													{

														my_Ramp_Init_t.ramp_timer_Tout=0;
														my_Ramp_Init_t.Ramp_Gen_State=Ramp_Gen_Inactive;
														//HAL_GPIO_WritePin(DO_Inv_Outdrv_Dis_GPIO_Port, DO_Inv_Outdrv_Dis_Pin, GPIO_PIN_RESET);
														//HAL_DAC_SetValue(&hdac1, DAC_CHANNEL_2, DAC_ALIGN_12B_R,I_Valley_DAC_Value);
														//HAL_DAC_Stop_DMA(&hdac1, DAC_CHANNEL_2);

														//HAL_DAC_SetValue(&hdac1, DAC_CHANNEL_2, DAC_ALIGN_12B_R,I_Valley_DAC_Value);

													}
													//else

													//HAL_DAC_Start_DMA(&hdac1, DAC_CHANNEL_2, Ramp_Weld1_Array, Ramp_Weld1_Arraysize, DAC_ALIGN_12B_R);


													//Always at exit a check is done if Potentiometer is set again to less than Valley Current
														if(I_Set_ADC_Value < (I_Valley_DAC_Value-10))
															{
															 hRamp_t->Ramp_Gen_State= Ramp_Gen_Inactive;
															}
													break;

									}

								break;



			}
	}



void PSFB_CTRL_Config(void)
{
	HAL_GPIO_WritePin(nDO_PSFB_CTRL_On_GPIO_Port, nDO_PSFB_CTRL_On_Pin, GPIO_PIN_RESET);// Enabling UCC28951
	//Later, the If statements that condition the enabling of the Gate Drivers shall be added here
	HAL_GPIO_WritePin(DO_G_DRV_EN_GPIO_Port, DO_G_DRV_EN_Pin,GPIO_PIN_SET );
	//Setting the Reference Signal
   		my_Ramp_Init_t.Ipeak=184;//[A]
   		my_Ramp_Init_t.Ivalley=104;//[A]
   		my_Ramp_Init_t.I_Step1=175;//[A]
   		my_Ramp_Init_t.I_Rampdown=18;//[A]
   		my_Ramp_Init_t.T_DAC_Sample=50; //[us]
   		my_Ramp_Init_t.T_Ramp_On=14000;//[us]
   		my_Ramp_Init_t.T_Step1=1500;//[us]
   		my_Ramp_Init_t.T_Rise=6000;//[us]
   		my_Ramp_Init_t.T_Peak=1600;//[us]
   		my_Ramp_Init_t.T_Fall=4400;//[us]
   		my_Ramp_Init_t.Pulseduty=50; //%
   		my_Ramp_Init_t.Ramptype=I_Ramp_Weld2;
   		my_Ramp_Init_t.ramp_timer=htim3;
   		my_Ramp_Init_t.Ramp_Gen_State= Ramp_Gen_Inactive;
   		Ramp_Generator_Config(&my_Ramp_Init_t);

   		hHMI.Display_Index=0;
}


void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{

	// Every 2ms a complete ADC scan is complete
  /* Prevent unused argument(s) compilation warning */
  UNUSED(hadc);
  	  ADC_Scan_Complete_F=1;
  	  //HAL_GPIO_TogglePin(DO_Inv_Outdrv_Dis_GPIO_Port, DO_Inv_Outdrv_Dis_Pin);
  	//HAL_GPIO_WritePin(DO_Inv_Outdrv_Dis_GPIO_Port, DO_Inv_Outdrv_Dis_Pin, GPIO_PIN_SET);
  	  //HAL_ADC_Stop_DMA(&hadc1);
  	  I_Set_ADC_Value=ADC_Rawdata_Buffer_DMA[0];
  	//taking out the offset from measured Potentiometer ADC.
  	if(I_Set_ADC_Value>I_Set_ADC_Offset)
  	 	  	 	  	{
  	 	  	 	  	 I_Set_ADC_Value-=I_Set_ADC_Offset;
  	 	  	 	  	}
  	 	  	 else
  	 	  	 	  	 I_Set_ADC_Value=0;

  	 Ea_ADC_Value= ADC_Rawdata_Buffer_DMA[4];
  	 Io_ADC_Value= ADC_Rawdata_Buffer_DMA[1];
  	//HAL_GPIO_WritePin(DO_Inv_Outdrv_Dir_GPIO_Port, DO_Inv_Outdrv_Dir_Pin, GPIO_PIN_SET);
  	 //HAL_GPIO_WritePin(DO_Inv_Outdrv_Dis_GPIO_Port, DO_Inv_Outdrv_Dis_Pin, GPIO_PIN_RESET);
  	Extract_ADC_Arrays((uint16_t*)ADC_Rawdata_Buffer_DMA,(uint16_t*) Ea_ADC_Samples,(uint16_t*) Io_ADC_Samples,Num_Ea_ADC_Samples);
  	//HAL_GPIO_WritePin(DO_Inv_Outdrv_Dir_GPIO_Port, DO_Inv_Outdrv_Dir_Pin, GPIO_PIN_RESET);
  	Ea_Av= MovingAverage_Ea(Ea_ADC_Value,(uint16_t*) &Ea_ADC_Samples,Num_Ea_ADC_Samples);
  	Ea_Av_mV=(uint16_t)(Ea_Av*2*3300/(0xFFF));


	 if(Ea_Av_mV>Ea_Av_mV_THD)
  			 Rweld=High; // This is set like a flag
	 /*
	 {
  		 else
  			 Rweld=Low;
	 }
	 */
  	//HAL_GPIO_WritePin(DO_Inv_Outdrv_Dis_GPIO_Port, DO_Inv_Outdrv_Dis_Pin, GPIO_PIN_RESET);

}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
