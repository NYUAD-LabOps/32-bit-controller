/*
 * hmi_driver.c
 *
 *  Created on: Feb 10, 2024
 *      Author: ah5743
 */

#include "hmi_driver.h"
#include "main.h"

extern HMI_t hHMI;

HMI_Display (uint16_t NumberToDisplay)
{

hHMI.Display_Index;
hHMI.Ones= NumberToDisplay%10;
hHMI.Tens =((NumberToDisplay/10)%10);
hHMI.Hundreds=((NumberToDisplay/100)%10);


Ones_BCD=BinaryToBCD((uint8_t)hHMI.Ones);


Tens_BCD=BinaryToBCD((uint8_t)hHMI.Tens);


Hundreds_BCD=BinaryToBCD((uint8_t) hHMI.Hundreds);



//Increment_Display_Index();


// If the current digit is 2, wrap around to 0
if (hHMI.Display_Index == 2)
	{
	hHMI.Display_Index = 0;
	}
else
{
    // Otherwise, move to the next digit
	hHMI.Display_Index++;
}

//Clear the displayed value from the three seven  segment displays
HAL_GPIO_WritePin(GPIOC, DO_7XSEGMENT_1_EN, GPIO_PIN_RESET);
HAL_GPIO_WritePin(GPIOC, DO_7XSEGMENT_2_EN, GPIO_PIN_RESET);
HAL_GPIO_WritePin(GPIOC, DO_7XSEGMENT_3_EN, GPIO_PIN_RESET);

HAL_GPIO_WritePin(Port_BCD_X, DO_BCD_A, GPIO_PIN_SET);
HAL_GPIO_WritePin(Port_BCD_X, DO_BCD_B, GPIO_PIN_SET);
HAL_GPIO_WritePin(Port_BCD_X, DO_BCD_C, GPIO_PIN_SET);
HAL_GPIO_WritePin(Port_BCD_X, DO_BCD_D, GPIO_PIN_SET);

switch (hHMI.Display_Index)
{
case 0:// This is the RHS display (Ones)
	HAL_GPIO_WritePin(GPIOB, DO_7XSEGMENT_1_EN, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOC, DO_7XSEGMENT_2_EN, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOC, DO_7XSEGMENT_3_EN, GPIO_PIN_SET);
	hHMI.BCDA=(Ones_BCD & 0X01);
	hHMI.BCDB=((Ones_BCD>>1) &0x01);
	hHMI.BCDC= ((Ones_BCD>>2) & 0X01);
	hHMI.BCDD= ((Ones_BCD>>3) & 0X01);
	break;
case 1:// This is the middle one(Tens)
	HAL_GPIO_WritePin(GPIOB, DO_7XSEGMENT_1_EN, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOC, DO_7XSEGMENT_3_EN, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOC, DO_7XSEGMENT_2_EN, GPIO_PIN_SET);
	hHMI.BCDA=(Tens_BCD & 0X01);
	hHMI.BCDB=((Tens_BCD>>1) &0x01);
	hHMI.BCDC= ((Tens_BCD>>2) & 0X01);
	hHMI.BCDD= ((Tens_BCD>>3) & 0X01);

	break;

case 2:// This is the LHS display (Hundreds)
	HAL_GPIO_WritePin(GPIOC, DO_7XSEGMENT_2_EN, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOC, DO_7XSEGMENT_3_EN, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOB, DO_7XSEGMENT_1_EN, GPIO_PIN_SET);
	hHMI.BCDA=(Hundreds_BCD & 0X01);
	hHMI.BCDB=((Hundreds_BCD>>1) &0x01);
	hHMI.BCDC= ((Hundreds_BCD>>2) & 0X01);
	hHMI.BCDD= ((Hundreds_BCD>>3) & 0X01);
	break;
}

// Now Write the BCD_Values to the corresponding BCD Pins.

if(hHMI.BCDA==1)
	{
	HAL_GPIO_WritePin(Port_BCD_X, DO_BCD_A, GPIO_PIN_RESET);
	}
	else
	HAL_GPIO_WritePin(Port_BCD_X, DO_BCD_A, GPIO_PIN_SET);

if(hHMI.BCDB==1)
	{
	HAL_GPIO_WritePin(Port_BCD_X, DO_BCD_B, GPIO_PIN_RESET);
	}
	else
	HAL_GPIO_WritePin(Port_BCD_X, DO_BCD_B, GPIO_PIN_SET);
if(hHMI.BCDC==1)
	{
	HAL_GPIO_WritePin(Port_BCD_X, DO_BCD_C, GPIO_PIN_RESET);
	}
	else
	HAL_GPIO_WritePin(Port_BCD_X, DO_BCD_C, GPIO_PIN_SET);
if(hHMI.BCDD==1)
	{
	HAL_GPIO_WritePin(Port_BCD_X, DO_BCD_D, GPIO_PIN_RESET);
	}
	else
	HAL_GPIO_WritePin(Port_BCD_X, DO_BCD_D, GPIO_PIN_SET);


}




uint8_t BinaryToBCD (uint8_t BinaryDigit)
{
	uint8_t BCD_Code =0;
	BCD_Code =((BinaryDigit/10)<<4)|(BinaryDigit%10);
	return BCD_Code;
}


/*
void Increment_Display_Index(void)
{
    // If the current digit is 2, wrap around to 0
    if (hHMI.Display_Index == 2)
    	{
    	hHMI.Display_Index = 0;
    	}
    else
    {
        // Otherwise, move to the next digit
    	hHMI.Display_Index++;
    }
}
*/
