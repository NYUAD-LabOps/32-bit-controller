/*
 * hmi_driver.h
 *
 *  Created on: Feb 10, 2024
 *      Author: ah5743
 */

#ifndef INC_HMI_DRIVER_H_
#define INC_HMI_DRIVER_H_
#include "main.h"





#define DO_BCD_A DO_7SEG_BCD_A_Pin
#define DO_BCD_B DO_7SEG_BCD_B_Pin
#define DO_BCD_C DO_7SEG_BCD_C_Pin
#define DO_BCD_D DO_7SEG_BCD_D_Pin

#define DO_7XSEGMENT_1_EN DO_7SEG_DISP1_EN_Pin
#define DO_7XSEGMENT_2_EN DO_7SEG_DISP2_EN_Pin
#define DO_7XSEGMENT_3_EN DO_7SEG_DISP3_EN_Pin

#define Port_7XSEGMENT_1_EN GPIOB
#define Port_7XSEGMENT_2_EN GPIOC
#define Port_7XSEGMENT_3_EN GPIOC

#define Port_BCD_X DO_7SEG_BCD_A_GPIO_Port // All BCD Pins are at GPIOC Port

void HMI_Display(uint16_t );

uint8_t Ones_BCD;
uint8_t Tens_BCD;
uint8_t Hundreds_BCD;

uint8_t BinaryToBCD (uint8_t );
#endif /* INC_HMI_DRIVER_H_ */
