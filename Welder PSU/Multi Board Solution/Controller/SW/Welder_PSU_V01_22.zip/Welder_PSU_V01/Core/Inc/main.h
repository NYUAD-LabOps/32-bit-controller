/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32g0xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define DO_7SEG_DISP3_EN_Pin GPIO_PIN_11
#define DO_7SEG_DISP3_EN_GPIO_Port GPIOC
#define DO_7SEG_BCD_D_Pin GPIO_PIN_12
#define DO_7SEG_BCD_D_GPIO_Port GPIOC
#define DO_7SEG_BCD_C_Pin GPIO_PIN_13
#define DO_7SEG_BCD_C_GPIO_Port GPIOC
#define DO_7SEG_BCD_B_Pin GPIO_PIN_14
#define DO_7SEG_BCD_B_GPIO_Port GPIOC
#define DO_7SEG_BCD_A_Pin GPIO_PIN_15
#define DO_7SEG_BCD_A_GPIO_Port GPIOC
#define DO_UART_TX_Pin GPIO_PIN_0
#define DO_UART_TX_GPIO_Port GPIOC
#define DI_UART_RX_Pin GPIO_PIN_1
#define DI_UART_RX_GPIO_Port GPIOC
#define nComm_Rx_EN_Pin GPIO_PIN_2
#define nComm_Rx_EN_GPIO_Port GPIOC
#define AI_Temp_QD_Pin GPIO_PIN_1
#define AI_Temp_QD_GPIO_Port GPIOA
#define AI_Temp_QB_Pin GPIO_PIN_2
#define AI_Temp_QB_GPIO_Port GPIOA
#define AI_Temp_HS_Pin GPIO_PIN_3
#define AI_Temp_HS_GPIO_Port GPIOA
#define DO_Comm_Tx_En_Pin GPIO_PIN_7
#define DO_Comm_Tx_En_GPIO_Port GPIOA
#define AI_I_Out_Pin GPIO_PIN_0
#define AI_I_Out_GPIO_Port GPIOB
#define AI_I_Set_Pin GPIO_PIN_1
#define AI_I_Set_GPIO_Port GPIOB
#define DO_Abrupt_I_Off_Pin GPIO_PIN_11
#define DO_Abrupt_I_Off_GPIO_Port GPIOA
#define nDO_PSFB_CTRL_On_Pin GPIO_PIN_12
#define nDO_PSFB_CTRL_On_GPIO_Port GPIOA
#define DO_V_Set_PWM_Pin GPIO_PIN_8
#define DO_V_Set_PWM_GPIO_Port GPIOC
#define DO_G_DRV_EN_Pin GPIO_PIN_0
#define DO_G_DRV_EN_GPIO_Port GPIOD
#define DI_G_DRV_RDY_Pin GPIO_PIN_1
#define DI_G_DRV_RDY_GPIO_Port GPIOD
#define nDI_G_DRV_FaultD_Pin GPIO_PIN_2
#define nDI_G_DRV_FaultD_GPIO_Port GPIOD
#define nDI_G_DRV_FaultC_Pin GPIO_PIN_3
#define nDI_G_DRV_FaultC_GPIO_Port GPIOD
#define nDI_G_DRV_FaultB_Pin GPIO_PIN_4
#define nDI_G_DRV_FaultB_GPIO_Port GPIOD
#define nDI_G_DRV_FaultA_Pin GPIO_PIN_5
#define nDI_G_DRV_FaultA_GPIO_Port GPIOD
#define DI_Outdrv_Fault_Pin GPIO_PIN_4
#define DI_Outdrv_Fault_GPIO_Port GPIOB
#define DO_Inv_Predrv_En_Pin GPIO_PIN_5
#define DO_Inv_Predrv_En_GPIO_Port GPIOB
#define DO_Inv_Outdrv_Dir_Pin GPIO_PIN_6
#define DO_Inv_Outdrv_Dir_GPIO_Port GPIOB
#define DO_Inv_Outdrv_Dis_Pin GPIO_PIN_7
#define DO_Inv_Outdrv_Dis_GPIO_Port GPIOB
#define DO_7SEG_DISP1_EN_Pin GPIO_PIN_9
#define DO_7SEG_DISP1_EN_GPIO_Port GPIOB
#define DO_7SEG_DISP2_EN_Pin GPIO_PIN_10
#define DO_7SEG_DISP2_EN_GPIO_Port GPIOC

/* USER CODE BEGIN Private defines */
typedef struct{
	uint16_t Ivalley; //current value of Base Current, I_CC current [A]
	uint16_t Ipeak; //Peak Value[A]
	uint16_t I_Step1;// Current in[A] of first step above Ivalley in I_Ramp_Weld1 profile
	uint16_t I_Rampdown;//The current drop from Ivalley, when the current ramps down.
	uint16_t T_Step1;// [us]
	uint16_t T_Rise; //[us]
	uint16_t T_Peak; //[us]
	uint16_t T_Fall; //[us]
	uint16_t T_DAC_Sample; //[us]
	uint16_t T_Ramp_On; //[us], this is the time the current is above I_Valley
	uint8_t Pulseduty;// Dutycycle in %
	TIM_HandleTypeDef ramp_timer;
	uint8_t volatile Ramptype				:4;
	uint8_t volatile Ramp_Gen_State	:1;
	uint8_t volatile ramp_timer_Tout:1;
}Ramp_t;


typedef struct{
	uint8_t Ones;
	uint8_t Tens;
	uint8_t Hundreds;
	uint8_t BCDA :1;
	uint8_t BCDB :1;
	uint8_t BCDC :1;
	uint8_t BCDD :1;
	uint8_t volatile Display_Index; // shall be static volatile?
}HMI_t;


#define Vref_Step_Down 0.91	//Voltage Divider after DAC Output, at Compensator non-inverting Input
#define DAC_Vref	3300		//mV , the reference voltage of the DAC.
#define Av_Out_Offset 80 //mV, this is Av Output at zero Weld current.
/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
